test_data = [
    {
        "name": "Hisense 50\" 4K Smart Google AI Upscaler LED TV - 50A68N",
        "price": "$379.00",
        "link": "products/hisense-50-4k-smart-google-ai-upscaler-led-tv-50a68n"
    },
    # {
    #     "name": "Hisense 55\" 4K Smart Google AI Upscaler LED TV - 55A68N",
    #     "price": "$449.00",
    #     "link": "products/hisense-55-4k-smart-google-ai-upscaler-led-tv-55a68n"
    # },    
    # {
    #     "name": "Samsung 75\u201d 4K Tizen Smart CUHD TV - UN75DU7100FXZC",
    #     "price": "$899.00",
    #     "link": "products/samsung-75-4k-tizen-smart-cuhd-tv-un75du7100fxzc"
    # },
    # {
    #     "name": "LG 50\" UHD 4K Smart LED TV - 50UT7570PUB",
    #     "price": "$499.00",
    #     "link": "products/lg-50-uhd-4k-smart-led-tv-50ut7570pub"
    # },
] 

